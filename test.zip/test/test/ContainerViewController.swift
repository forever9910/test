//
//  ContainerViewController.swift
//  test
//
//  Created by niu on 2021/10/6.
//  Copyright © 2021 niu. All rights reserved.
//

import UIKit

class ContainerViewController: UIViewController {
	@IBOutlet weak var web: UIView!
	@IBOutlet weak var data: UIView!
	
	var webvc : WebTestViewController!
	var datavc : TableController!
	
    override func viewDidLoad() {
        super.viewDidLoad()
		setupChildViewControllers()

        // Do any additional setup after loading the view.
    }
    
	private func setupChildViewControllers() {
			let storyboard = UIStoryboard(name: "Main", bundle: nil)
			
			let webvc = storyboard.instantiateViewController(withIdentifier: "WebTestViewController") as! WebTestViewController
			//addChild(childController: webvc, to: web)
			self.webvc = webvc
			//self.webvc.delegate = self
			
			let datavc = storyboard.instantiateViewController(withIdentifier: "TableController") as! TableController
			//datavc.movies = movies
			//addChild(childController: datavc, to: TableController)
			self.datavc = datavc
		}

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

//extension ContainerViewController : WebTestViewControllerDelegate{
	//func webvc() {
		
	//}
//}
