//
//  ViewController.swift
//  test
//
//  Created by niu on 2021/8/2.
//  Copyright © 2021 niu. All rights reserved.
//

import UIKit
import UserNotifications

class ViewController: UIViewController {
	
	
	override func viewDidLoad() {
		super.viewDidLoad()
		print("start")
		// Do any additional setup after loading the view.
		createNotification()
		
	}
		
	func createNotification() {
			
			let content = UNMutableNotificationContent()
			
			content.title = "Notice"
			content.subtitle = "test"
			content.body = "how are you"
			content.badge = 1
			content.sound = UNNotificationSound.default
			content.categoryIdentifier = "alarmMessage"
		
		let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 3, repeats: false)
				let request = UNNotificationRequest(identifier: "notification", content: content, trigger: trigger)
				
				UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
	
}
}
